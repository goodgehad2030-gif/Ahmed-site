/* صيدلية أحمد العشلة — لوحة التحكم (تُحمَّل عند الطلب من app.js) */
(() => {
  "use strict";
  const P = window.Pharmacy;
  const { CONFIG, CATEGORIES, esc, ico, toast } = P;
  const $ = id => document.getElementById(id);

  let root, authed = false, editingId = null, imgData = "";

  const TEMPLATE = `
  <div class="adm__panel" role="dialog" aria-modal="true" aria-labelledby="admTitle">
    <div class="adm__bar">
      <h2 id="admTitle">لوحة التحكم</h2>
      <div class="adm__acts" id="admActs" hidden>
        <button class="btn btn--outline btn--sm" id="bExport" type="button">تصدير products.json</button>
        <button class="btn btn--outline btn--sm" id="bImport" type="button">استيراد</button>
        <input type="file" id="fImport" accept="application/json,.json" hidden>
      </div>
      <button class="icon-btn" id="bClose" type="button" aria-label="إغلاق">${ico("x", 22)}</button>
    </div>

    <div class="adm__body" id="admLogin">
      <p class="adm__hint">أدخل كلمة المرور للمتابعة.</p>
      <div class="adm__row"><input class="adm__in" id="pw" type="password" placeholder="كلمة المرور" autocomplete="current-password">
      <button class="btn btn--primary btn--sm" id="bLogin" type="button">دخول</button></div>
    </div>

    <div class="adm__body" id="admMain" hidden>
      <p class="adm__hint" id="hint">التعديلات تُحفظ كمسودة على هذا الجهاز. لنشرها للجميع: صدّر products.json وارفعه بجانب index.html.</p>

      <div class="adm__form">
        <h3 id="formTitle">إضافة منتج</h3>
        <label>اسم المنتج *<input class="adm__in" id="fName" maxlength="120"></label>
        <label>القسم<select class="adm__in" id="fCat"></select></label>
        <label>الوصف<textarea class="adm__in" id="fDesc" rows="2" maxlength="220"></textarea></label>
        <div class="adm__two">
          <label>السعر<input class="adm__in" id="fPrice" type="number" min="0" inputmode="numeric" placeholder="فارغ = اسأل عن السعر"></label>
          <label>السعر قبل الخصم<input class="adm__in" id="fOld" type="number" min="0" inputmode="numeric" placeholder="اختياري"></label>
        </div>
        <p class="adm__disc" id="fDisc" aria-live="polite"></p>
        <label>شارة (اختياري)<input class="adm__in" id="fBadge" maxlength="30" placeholder="مثال: الأكثر طلبًا"></label>
        <div class="adm__checks">
          <label><input type="checkbox" id="fStock" checked> متوفر</label>
          <label><input type="checkbox" id="fOffer"> عرض خاص</label>
          <label><input type="checkbox" id="fNew"> جديد</label>
          <label><input type="checkbox" id="fWa" checked> زر واتساب</label>
        </div>
        <div class="adm__img">
          <div class="adm__prev" id="fPrev">${ico("package", 28)}</div>
          <div class="adm__imgf">
            <input type="file" id="fFile" accept="image/*">
            <input class="adm__in" id="fPath" placeholder="أو مسار صورة: images/product.webp" dir="ltr">
          </div>
        </div>
        <div class="adm__row">
          <button class="btn btn--primary btn--sm" id="bSave" type="button">حفظ المنتج</button>
          <button class="btn btn--outline btn--sm" id="bCancel" type="button" hidden>إلغاء التعديل</button>
        </div>
      </div>

      <div class="adm__listhead">
        <h3>المنتجات (<span id="cnt">0</span>)</h3>
        <input class="adm__in" id="aq" type="search" placeholder="بحث...">
      </div>
      <ul class="adm__list" id="alist"></ul>
      <div class="adm__row"><button class="btn btn--outline btn--sm" id="bReset" type="button">حذف المسودة والعودة للأصل</button></div>
    </div>
  </div>`;

  /* زر يحتاج ضغطتين للتأكيد (للحذف) */
  function armBtn(btn, label, action) {
    let armed = false, t;
    btn.addEventListener("click", () => {
      if (!armed) { armed = true; btn.textContent = "اضغط للتأكيد"; btn.classList.add("is-armed"); t = setTimeout(reset, 3000); return; }
      clearTimeout(t); reset(); action();
    });
    function reset() { armed = false; btn.textContent = label; btn.classList.remove("is-armed"); }
  }

  function build() {
    root = document.createElement("div");
    root.className = "adm"; root.id = "adm"; root.hidden = true;
    root.innerHTML = TEMPLATE;
    document.body.appendChild(root);

    $("fCat").innerHTML = CATEGORIES.map(c => `<option>${esc(c.name)}</option>`).join("");
    $("bClose").addEventListener("click", close);
    root.addEventListener("click", e => { if (e.target === root) close(); });
    document.addEventListener("keydown", e => { if (e.key === "Escape" && !root.hidden) close(); });

    const login = () => {
      if ($("pw").value === CONFIG.adminPass) { authed = true; setView(); }
      else { toast("كلمة المرور غير صحيحة"); $("pw").select(); }
    };
    $("bLogin").addEventListener("click", login);
    $("pw").addEventListener("keydown", e => { if (e.key === "Enter") login(); });

    $("bSave").addEventListener("click", saveProduct);
    $("bCancel").addEventListener("click", resetForm);
    $("fPrice").addEventListener("input", updateDisc);
    $("fOld").addEventListener("input", updateDisc);
    $("aq").addEventListener("input", renderList);
    $("fFile").addEventListener("change", onFile);
    $("fPath").addEventListener("input", () => { imgData = $("fPath").value.trim(); setPrev(imgData); });

    $("bExport").addEventListener("click", exportJson);
    $("bImport").addEventListener("click", () => $("fImport").click());
    $("fImport").addEventListener("change", importJson);
    armBtn($("bReset"), "حذف المسودة والعودة للأصل", async () => { await P.reset(); resetForm(); renderList(); toast("تمت العودة للبيانات الأصلية"); });
  }

  function setView() {
    $("admLogin").hidden = authed; $("admMain").hidden = !authed; $("admActs").hidden = !authed;
    if (authed) { renderList(); resetForm(); }
  }
  function open() {
    if (!root) build();
    root.hidden = false; document.body.style.overflow = "hidden";
    setView();
    (authed ? $("fName") : $("pw")).focus();
  }
  function close() {
    root.hidden = true; document.body.style.overflow = "";
    if (location.hash === "#admin") history.replaceState(null, "", location.pathname + location.search);
  }

  /* ----- معاينة الخصم ----- */
  function updateDisc() {
    const price = +$("fPrice").value || null, old = +$("fOld").value || null;
    const el = $("fDisc");
    if (price && old && old <= price) { el.textContent = "السعر قبل الخصم يجب أن يكون أكبر من السعر الحالي."; el.className = "adm__disc is-bad"; return; }
    const d = P.discountPct({ price, oldPrice: old });
    el.textContent = d ? `سيظهر خصم ${d}% تلقائيًا` : "";
    el.className = "adm__disc";
  }

  /* ----- الصورة ----- */
  function setPrev(src) {
    $("fPrev").innerHTML = src ? `<img src="${esc(src)}" alt="" onerror="this.remove()">` : ico("package", 28);
  }
  function onFile(e) {
    const f = e.target.files[0];
    if (!f) return;
    const img = new Image(), url = URL.createObjectURL(f);
    img.onload = () => {
      const max = 800, k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      let data = c.toDataURL("image/webp", .82);
      if (!data.startsWith("data:image/webp")) data = c.toDataURL("image/jpeg", .82);   // متصفح بلا WebP
      URL.revokeObjectURL(url);
      imgData = data; $("fPath").value = ""; setPrev(data);
    };
    img.onerror = () => { URL.revokeObjectURL(url); toast("تعذّر قراءة الصورة"); };
    img.src = url;
  }

  /* ----- النموذج ----- */
  function resetForm() {
    editingId = null; imgData = "";
    ["fName", "fDesc", "fPrice", "fOld", "fBadge", "fPath"].forEach(i => { $(i).value = ""; });
    $("fFile").value = "";
    $("fCat").selectedIndex = 0;
    $("fStock").checked = true; $("fOffer").checked = false; $("fNew").checked = true; $("fWa").checked = true;
    $("formTitle").textContent = "إضافة منتج";
    $("bSave").textContent = "حفظ المنتج";
    $("bCancel").hidden = true;
    setPrev(""); updateDisc();
  }
  function editProduct(id) {
    const p = P.products.find(x => x.id === id);
    if (!p) return;
    editingId = id; imgData = p.image;
    $("fName").value = p.name; $("fDesc").value = p.description;
    $("fPrice").value = p.price ?? ""; $("fOld").value = p.oldPrice ?? ""; $("fBadge").value = p.badge;
    if (![...$("fCat").options].some(o => o.value === p.category) && p.category) $("fCat").add(new Option(p.category));
    $("fCat").value = p.category || $("fCat").options[0].value;
    $("fStock").checked = p.inStock; $("fOffer").checked = p.offer; $("fNew").checked = p.isNew; $("fWa").checked = p.whatsapp;
    $("fPath").value = p.image.startsWith("data:") ? "" : p.image;
    $("formTitle").textContent = "تعديل منتج";
    $("bSave").textContent = "حفظ التعديل";
    $("bCancel").hidden = false;
    setPrev(p.image); updateDisc();
    $("fName").scrollIntoView({ block: "center" }); $("fName").focus();
  }
  function saveProduct() {
    const name = $("fName").value.trim();
    if (!name) { toast("اكتب اسم المنتج"); $("fName").focus(); return; }
    const price = $("fPrice").value === "" ? null : +$("fPrice").value;
    const oldPrice = $("fOld").value === "" ? null : +$("fOld").value;
    if (price && oldPrice && oldPrice <= price) { toast("السعر قبل الخصم يجب أن يكون أكبر من السعر الحالي"); $("fOld").focus(); return; }
    const item = {
      name, description: $("fDesc").value.trim(), image: imgData, price, oldPrice,
      offer: $("fOffer").checked, category: $("fCat").value, badge: $("fBadge").value.trim(),
      whatsapp: $("fWa").checked, inStock: $("fStock").checked, isNew: $("fNew").checked
    };
    const list = P.products;
    if (editingId) {
      const i = list.findIndex(x => x.id === editingId);
      if (i > -1) list[i] = { ...list[i], ...item };
    } else {
      list.unshift({ ...item, id: "p-" + Date.now().toString(36) });
    }
    P.save(list);
    toast(editingId ? "تم حفظ التعديل" : "تمت إضافة المنتج");
    resetForm(); renderList();
  }

  /* ----- القائمة ----- */
  function renderList() {
    const q = $("aq").value.trim().toLowerCase();
    const all = P.products;
    const list = all.filter(p => !q || (p.name + " " + p.category).toLowerCase().includes(q));
    $("cnt").textContent = all.length;
    const ul = $("alist");
    ul.innerHTML = list.length ? list.map(p => {
      const d = P.discountPct(p);
      const meta = [esc(p.category || "بدون قسم"), p.price ? `${p.price} ${esc(CONFIG.currency)}${d ? ` (خصم ${d}%)` : ""}` : "بدون سعر"].join(" · ");
      const flags = [p.offer && "عرض", p.isNew && "جديد", p.badge && esc(p.badge), !p.inStock && "غير متوفر", !p.whatsapp && "بدون واتساب"].filter(Boolean);
      return `<li class="adm__item" data-id="${esc(p.id)}">
        <div class="adm__thumb">${p.image ? `<img src="${esc(p.image)}" alt="" loading="lazy" onerror="this.remove()">` : ico("package", 22)}</div>
        <div class="adm__info"><b>${esc(p.name)}</b><span>${meta}</span>${flags.length ? `<em>${flags.join(" · ")}</em>` : ""}</div>
        <div class="adm__btns"><button class="btn btn--outline btn--sm" type="button" data-edit>تعديل</button><button class="btn btn--outline btn--sm adm__del" type="button" data-del>حذف</button></div>
      </li>`;
    }).join("") : '<li class="adm__empty">لا توجد منتجات.</li>';
    ul.querySelectorAll(".adm__item").forEach(li => {
      const id = li.dataset.id;
      li.querySelector("[data-edit]").addEventListener("click", () => editProduct(id));
      armBtn(li.querySelector("[data-del]"), "حذف", () => {
        P.save(P.products.filter(x => x.id !== id));
        if (editingId === id) resetForm();
        renderList(); toast("تم حذف المنتج");
      });
    });
  }

  /* ----- تصدير / استيراد ----- */
  function exportJson() {
    const blob = new Blob([JSON.stringify(P.products, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "products.json";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    toast("تم تصدير products.json");
  }
  function importJson(e) {
    const f = e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      try {
        const j = JSON.parse(r.result);
        if (!Array.isArray(j)) throw new Error("not array");
        const list = P.normalizeList(j);          // يقبل الشكل القديم والجديد
        if (!list.length) throw new Error("empty");
        P.save(list); resetForm(); renderList();
        toast(`تم استيراد ${list.length} منتج`);
      } catch (err) { toast("ملف غير صالح: يجب أن يكون قائمة منتجات JSON"); }
      e.target.value = "";
    };
    r.readAsText(f);
  }

  window.PharmacyAdmin = { open };
})();
