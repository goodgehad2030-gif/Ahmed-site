/* =====================================================================
   صيدلية أحمد العشلة — البيانات والإعدادات
   هذا هو الملف الوحيد الذي تحتاج تعديله لتغيير المنتجات أو الأقسام.
   ===================================================================== */
window.PHARMACY_DATA = {

  /* ---------- الإعدادات العامة ---------- */
  CONFIG: {
    siteName:  "صيدلية أحمد العشلة",
    whatsapp:  "967730408282",            // الرقم الدولي بدون + أو أصفار
    phone:     "+967730408282",           // لزر الاتصال
    currency:  "ريال",
    currencyCode: "YER",                  // لبيانات Schema.org
    address:   "شبوة - عتق - الشارع العام - أمام مركز شنيدوف",
    hours:     "على مدار الساعة، 24 ساعة يوميًا",
    instagram: "Aleshla_pharmacy",
    adminPass: "ashla2026",               // كلمة مرور لوحة التحكم. غيّرها قبل النشر.
    pageSize:  12,                        // عدد المنتجات في كل دفعة
    newDays:   30                         // المنتج الذي له addedAt يُعدّ «جديدًا» خلال هذه المدة
  },

  /* ---------- الأقسام ----------
     name: اسم القسم (يجب أن يطابق category في المنتج)
     icon: أيقونة من مكتبة الأيقونات في index.html
     hint: سطر وصف قصير يظهر تحت الاسم                                  */
  CATEGORIES: [
    { name: "العناية بالبشرة",        icon: "drop",    hint: "ترطيب وحماية ونضارة" },
    { name: "العناية بالشعر",         icon: "hair",    hint: "شامبو وعلاجات" },
    { name: "الفيتامينات والمكملات",  icon: "leaf",    hint: "دعم يومي لصحتك" },
    { name: "الأدوية",                icon: "pill",    hint: "أدوية ومنتجات صحية" },
    { name: "مستلزمات الأطفال",       icon: "baby",    hint: "للأم والطفل" },
    { name: "العناية الشخصية",        icon: "sparkle", hint: "نظافة ومستلزمات يومية" },
    { name: "أجهزة ومستلزمات طبية",   icon: "steth",   hint: "قياس ومتابعة منزلية" }
  ],

  /* أسماء الأقسام القديمة → الجديدة (حتى لا تضيع المنتجات المحفوظة سابقًا) */
  LEGACY_CATEGORIES: {
    "أدوية ومنتجات صحية": "الأدوية",
    "الأم والطفل":        "مستلزمات الأطفال"
  },

  /* ---------- المنتجات ----------
     name         اسم المنتج
     description  وصف مختصر
     image        مسار الصورة، مثال: "images/products/serum.webp" (يُفضّل WebP). فارغ = أيقونة القسم
     price        السعر. null = تظهر عبارة «اسأل عن السعر»
     oldPrice     السعر قبل الخصم (اختياري). عند وجوده مع price تُحسب نسبة الخصم تلقائيًا
     offer        true = يظهر «عرض خاص» ويدخل في قسم العروض
     category     يجب أن يطابق اسم قسم من الأعلى
     badge        شارة اختيارية مثل «الأكثر طلبًا» أو «جديد»
     whatsapp     true = يظهر زر الطلب عبر واتساب
     inStock      true = متوفر / false = غير متوفر
     isNew        true = يظهر في فلتر «الجديد».
                  أو ضع addedAt: "2026-10-01" ويُعدّ جديدًا تلقائيًا لمدة newDays يومًا

     مثال منتج بخصم (احذف علامتي التعليق لتجربته):
     { name:"سيروم فيتامين سي", description:"سيروم لنضارة البشرة.", image:"images/products/serum.webp",
       price:17500, oldPrice:25000, offer:true, category:"العناية بالبشرة", badge:"الأكثر طلبًا",
       whatsapp:true, inStock:true, isNew:true },
  */
  PRODUCTS: [
    { name: "Sleepneed Melatonin 5 mg", description: "أقراص قابلة للمضغ.",
      image: "", price: 3000, oldPrice: null, offer: false,
      category: "الفيتامينات والمكملات", badge: "", whatsapp: true, inStock: true, isNew: false },

    { name: "مرطب بشرة يومي", description: "ترطيب خفيف للاستخدام اليومي.",
      image: "", price: null, oldPrice: null, offer: false,
      category: "العناية بالبشرة", badge: "", whatsapp: true, inStock: true, isNew: false },

    { name: "شامبو للعناية بالشعر", description: "تنظيف لطيف لفروة الرأس.",
      image: "", price: null, oldPrice: null, offer: true,
      category: "العناية بالشعر", badge: "", whatsapp: true, inStock: true, isNew: false },

    { name: "فيتامين سي", description: "مكمل غذائي. اسأل الصيدلي عن الجرعة المناسبة.",
      image: "", price: null, oldPrice: null, offer: false,
      category: "الفيتامينات والمكملات", badge: "", whatsapp: true, inStock: true, isNew: false },

    { name: "كريم حفاضات للأطفال", description: "حماية وترطيب لبشرة الطفل.",
      image: "", price: null, oldPrice: null, offer: false,
      category: "مستلزمات الأطفال", badge: "", whatsapp: true, inStock: true, isNew: false },

    { name: "جهاز قياس ضغط", description: "جهاز رقمي للاستخدام المنزلي.",
      image: "", price: null, oldPrice: null, offer: false,
      category: "أجهزة ومستلزمات طبية", badge: "", whatsapp: true, inStock: false, isNew: false },

    { name: "مسكن ومخفض للحرارة", description: "من الأدوية التي تُصرف دون وصفة. اقرأ النشرة قبل الاستخدام.",
      image: "", price: null, oldPrice: null, offer: false,
      category: "الأدوية", badge: "", whatsapp: true, inStock: true, isNew: false }
  ]
};
