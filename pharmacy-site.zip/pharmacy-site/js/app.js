/* =====================================================================
   صيدلية أحمد العشلة — منطق الواجهة
   البنية:  أدوات ← المخزن (Store) ← المستودع (Repo) ← واتساب ← العرض (Render) ← الأحداث
   جاهز مستقبلًا لـ: سلة مشتريات، لوحة تحكم أكبر، قاعدة بيانات (استبدل Repo.load فقط).
   ===================================================================== */
(() => {
  "use strict";

  const { CONFIG, CATEGORIES, LEGACY_CATEGORIES = {}, PRODUCTS: SEED } = window.PHARMACY_DATA;
  const $ = id => document.getElementById(id);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  /* ================= أدوات مساعدة ================= */
  const esc = s => String(s).replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  const fmt = new Intl.NumberFormat("en-US").format;
  const unsafeUrl = /^\s*(javascript|vbscript|data:(?!image\/))/i;
  const safeUrl = u => (unsafeUrl.test(u) ? "" : u);
  // توحيد النص العربي للبحث: يتجاهل التشكيل واختلاف الألف والياء والتاء المربوطة
  const fold = s => String(s).toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[أإآٱ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه")
    .replace(/\s+/g, " ").trim();
  const countLabel = n => (n === 0 ? "لا توجد منتجات" : n === 1 ? "منتج واحد" : n === 2 ? "منتجان" : n <= 10 ? `${n} منتجات` : `${n} منتجًا`);
  const ico = (name, size) => `<svg class="i"${size ? ` style="--s:${size}px"` : ""} aria-hidden="true"><use href="#i-${name}"/></svg>`;
  const catIcon = name => (CATEGORIES.find(c => c.name === name) || {}).icon || "pill";

  let toastTimer;
  function toast(msg) {
    const old = document.querySelector(".toast");
    if (old) old.remove();
    const t = document.createElement("div");
    t.className = "toast"; t.setAttribute("role", "status"); t.textContent = msg;
    document.body.appendChild(t);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.remove(), 2600);
  }

  /* ================= المخزن المحلي (مسودة هذا الجهاز) ================= */
  const KEY = "ashla_products_v1";           // نفس المفتاح القديم حتى لا تضيع المسودات
  let memStore = null;
  const Store = {
    get() { try { return localStorage.getItem(KEY); } catch (e) { return memStore; } },
    set(v) { try { localStorage.setItem(KEY, v); } catch (e) { memStore = v; } },
    del() { try { localStorage.removeItem(KEY); } catch (e) { memStore = null; } }
  };

  /* ================= المنتجات: توحيد الشكل ================= */
  const hash = s => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0; return h.toString(36); };
  const toNum = v => (v === null || v === undefined || v === "" || isNaN(+v) ? null : +v);

  // يقبل الشكل الجديد والقديم (cat/desc/stock) فلا تضيع بيانات سابقة
  function normalize(raw) {
    const p = raw || {};
    const name = String(p.name ?? "").trim();
    const cat = String(p.category ?? p.cat ?? "").trim();
    const price = toNum(p.price), oldPrice = toNum(p.oldPrice);
    return {
      id: p.id || "p-" + hash(name),
      name,
      description: String(p.description ?? p.desc ?? "").trim(),
      image: safeUrl(String(p.image ?? "").trim()),
      price: price > 0 ? price : null,
      oldPrice: oldPrice > 0 ? oldPrice : null,
      offer: !!p.offer,
      category: LEGACY_CATEGORIES[cat] || cat,
      badge: String(p.badge ?? "").trim(),
      whatsapp: p.whatsapp !== false,
      inStock: (p.inStock ?? p.stock) !== false,
      isNew: !!p.isNew,
      addedAt: String(p.addedAt ?? "")
    };
  }
  function normalizeList(list) {
    const seen = new Set();
    return list.map(normalize).filter(p => p.name).map(p => {
      while (seen.has(p.id)) p.id += "x";
      seen.add(p.id);
      return p;
    });
  }
  const discountPct = p => (p.price && p.oldPrice && p.oldPrice > p.price ? Math.round((1 - p.price / p.oldPrice) * 100) : 0);
  const isNewProduct = p => {
    if (p.isNew) return true;
    if (!p.addedAt) return false;
    const days = (Date.now() - Date.parse(p.addedAt)) / 864e5;
    return days >= 0 && days <= CONFIG.newDays;
  };

  /* ================= المستودع: مصدر البيانات =================
     الترتيب: data.js → products.json (إن وُجد على الخادم) → مسودة هذا الجهاز.
     لاحقًا يمكن استبدال هذه الدالة بطلب API لقاعدة بيانات.                     */
  let products = [];
  let draft = false;
  const Repo = {
    async load() {
      let list = SEED;
      if (location.protocol.startsWith("http")) {
        try {
          const r = await fetch("products.json?v=" + Date.now());
          if (r.ok) { const j = await r.json(); if (Array.isArray(j)) list = j; }
        } catch (e) { /* لا يوجد products.json: نكمل بالبيانات الافتراضية */ }
      }
      const d = Store.get();
      draft = false;
      if (d) { try { const j = JSON.parse(d); if (Array.isArray(j)) { list = j; draft = true; } } catch (e) { /* مسودة تالفة */ } }
      return normalizeList(list);
    },
    save(list) { products = normalizeList(list); Store.set(JSON.stringify(products)); draft = true; refresh(); showDraftPill(); },
    async reset() { Store.del(); products = await Repo.load(); refresh(); showDraftPill(); }
  };

  /* ================= واتساب ================= */
  const WhatsApp = {
    link: text => `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(text)}`,
    general: "السلام عليكم، أريد الاستفسار من صيدلية أحمد العشلة",
    product: p => `السلام عليكم، أريد الاستفسار عن منتج ${p.name} من موقع صيدلية أحمد العشلة.`
    // مستقبلًا (سلة المشتريات): cart: items => نص يجمع أسماء المنتجات وكمياتها
  };

  /* ================= الحالة والفلاتر ================= */
  const state = { q: "", cat: "all", offers: false, isNew: false, shown: CONFIG.pageSize };
  const hayCache = new WeakMap();
  const hay = p => { let h = hayCache.get(p); if (!h) { h = fold(p.name + " " + p.description); hayCache.set(p, h); } return h; };
  const isFiltered = () => !!(state.q.trim() || state.cat !== "all" || state.offers || state.isNew);

  function filtered() {
    const tokens = fold(state.q).split(" ").filter(Boolean);
    return products.filter(p =>
      (state.cat === "all" || p.category === state.cat) &&
      (!state.offers || p.offer) &&
      (!state.isNew || isNewProduct(p)) &&
      tokens.every(t => hay(p).includes(t)));
  }

  /* ================= العرض: البطاقات ================= */
  function cardHTML(p) {
    const d = discountPct(p);
    const tags = [];
    if (p.offer) tags.push('<span class="tag">عرض خاص</span>');
    if (p.badge && !(p.offer && p.badge === "عرض خاص")) tags.push(`<span class="tag tag--badge">${esc(p.badge)}</span>`);
    else if (!p.badge && isNewProduct(p)) tags.push('<span class="tag tag--new">جديد</span>');

    const icon = catIcon(p.category);
    const media = p.image
      ? `<img class="card__img" src="${esc(p.image)}" alt="${esc(p.name)}" width="400" height="400" loading="lazy" decoding="async" data-icon="${icon}">`
      : `<span class="card__ph">${ico(icon, 30)}</span>`;

    const price = p.price
      ? `<span class="price__now">${fmt(p.price)} <small>${esc(CONFIG.currency)}</small></span>` +
        (d ? `<del class="price__old"><span class="sr-only">السعر قبل الخصم </span>${fmt(p.oldPrice)}</del>` : "")
      : '<span class="price__ask">اسأل عن السعر</span>';

    const cta = p.whatsapp
      ? `<a class="btn btn--wa btn--sm btn--block card__cta" href="${WhatsApp.link(WhatsApp.product(p))}" target="_blank" rel="noopener" data-order>${ico("whatsapp", 20)}${p.inStock ? "اطلب عبر واتساب" : "اسأل عن التوفر"}</a>`
      : `<a class="btn btn--outline btn--sm btn--block card__cta" href="#contact">${ico("phone", 18)}تواصل معنا</a>`;

    return `<article class="card${p.inStock ? "" : " card--out"}">
      <div class="card__media">${media}
        ${tags.length ? `<div class="card__tags">${tags.slice(0, 2).join("")}</div>` : ""}
        ${d ? `<span class="card__disc">خصم ${d}%</span>` : ""}
      </div>
      <div class="card__body">
        ${p.category ? `<span class="card__cat">${esc(p.category)}</span>` : ""}
        <h3 class="card__title">${esc(p.name)}</h3>
        ${p.description ? `<p class="card__desc">${esc(p.description)}</p>` : ""}
        <div class="price">${price}</div>
        <span class="stock${p.inStock ? "" : " stock--out"}">${p.inStock ? "متوفر" : "غير متوفر"}</span>
        ${cta}
      </div>
    </article>`;
  }

  function emptyHTML(kind) {
    const q = state.q.trim();
    const t = kind === "offers"
      ? ["لا توجد عروض حاليًا", "اسأل الصيدلية عن آخر العروض عبر واتساب."]
      : q ? [`لم نجد «${esc(q)}»`, "جرّب كلمة أخرى، أو اسأل الصيدلية فقد يكون متوفرًا لدينا."]
      : state.isNew ? ["لا توجد منتجات جديدة حاليًا", "تصفّح كل المنتجات أو اسأل عن الجديد عبر واتساب."]
      : state.offers ? ["لا توجد عروض حاليًا", "تصفّح كل المنتجات أو اسأل عن العروض عبر واتساب."]
      : state.cat !== "all" ? ["لم نعرض منتجات هذا القسم بعد", "اسأل الصيدلية مباشرة، فالمتوفر في المحل أكثر من المعروض هنا."]
      : ["لا توجد منتجات حاليًا", "اسأل الصيدلية عن المنتج الذي تحتاجه."];
    const msg = q ? `السلام عليكم، أبحث عن ${q} من صيدلية أحمد العشلة، هل هو متوفر؟` : WhatsApp.general;
    return `<div class="empty">
      <div class="empty__icon">${ico(kind === "offers" ? "tag" : "search", 26)}</div>
      <p class="empty__title">${t[0]}</p>
      <p class="empty__text">${t[1]}</p>
      <div class="empty__actions">
        ${kind === "offers" ? "" : '<button class="btn btn--outline btn--sm" type="button" data-reset>عرض كل المنتجات</button>'}
        <a class="btn btn--wa btn--sm" href="${WhatsApp.link(msg)}" target="_blank" rel="noopener" data-order>${ico("whatsapp", 20)}اسأل عبر واتساب</a>
      </div>
    </div>`;
  }

  function renderGrid() {
    const list = filtered();
    const visible = list.slice(0, state.shown);
    const grid = $("grid");
    grid.innerHTML = visible.length ? visible.map(cardHTML).join("") : emptyHTML();
    grid.setAttribute("aria-busy", "false");
    $("count").textContent = countLabel(list.length);
    const rest = list.length - visible.length;
    $("more").hidden = rest <= 0;
    if (rest > 0) $("moreBtn").textContent = `عرض المزيد (${rest})`;
  }

  function renderOffers() {
    const list = products.filter(p => p.offer);
    $("offersGrid").innerHTML = list.length ? list.slice(0, 4).map(cardHTML).join("") : emptyHTML("offers");
    $("offersGrid").setAttribute("aria-busy", "false");
    $("allOffers").hidden = list.length <= 4;
  }

  function renderCategories() {
    const counts = {};
    products.forEach(p => { counts[p.category] = (counts[p.category] || 0) + 1; });
    const label = n => (n ? countLabel(n) : "اسأل عن المتوفر");
    const offerCount = products.filter(p => p.offer).length;
    $("cats").innerHTML = CATEGORIES.map(c => `
      <button class="cat" type="button" data-go-cat="${esc(c.name)}">
        <span class="cat__icon">${ico(c.icon, 24)}</span>
        <span class="cat__body">
          <span class="cat__name">${esc(c.name)}</span>
          <span class="cat__hint">${esc(c.hint || "")}</span>
          <span class="cat__count">${label(counts[c.name] || 0)}</span>
        </span>
      </button>`).join("") + `
      <button class="cat cat--offers" type="button" data-go-offers>
        <span class="cat__icon">${ico("tag", 24)}</span>
        <span class="cat__body">
          <span class="cat__name">العروض</span>
          <span class="cat__hint">منتجات عليها عروض</span>
          <span class="cat__count">${offerCount ? countLabel(offerCount) : "تابع عروضنا"}</span>
        </span>
      </button>`;
  }

  function renderStaticLists() {
    $("chips").innerHTML = `<button class="chip" type="button" data-chip="all">الكل</button>` +
      CATEGORIES.map(c => `<button class="chip" type="button" data-chip="${esc(c.name)}">${esc(c.name)}</button>`).join("");
    $("footCats").innerHTML = CATEGORIES.map(c => `<li><a href="#products" data-go-cat="${esc(c.name)}">${esc(c.name)}</a></li>`).join("");
  }

  /* مزامنة الواجهة مع الحالة */
  function syncUI() {
    $$(".chip").forEach(c => c.setAttribute("aria-pressed", String(c.dataset.chip === state.cat)));
    $("fOffers").setAttribute("aria-pressed", String(state.offers));
    $("fNew").setAttribute("aria-pressed", String(state.isNew));
    [$("q"), $("hq")].forEach(i => { if (i.value !== state.q) i.value = state.q; });
    $("qClear").hidden = !state.q;
    $("reset").hidden = !isFiltered();
    renderGrid();
  }
  function centerActiveChip() {
    const box = $("chips"), on = box.querySelector('[aria-pressed="true"]');
    if (!on || box.scrollWidth <= box.clientWidth) return;
    const b = box.getBoundingClientRect(), c = on.getBoundingClientRect();
    box.scrollBy({ left: (c.left + c.width / 2) - (b.left + b.width / 2), behavior: "smooth" });
  }
  function setFilters(patch, { scroll = false } = {}) {
    Object.assign(state, patch, { shown: CONFIG.pageSize });
    syncUI();
    centerActiveChip();
    if (scroll) $("products").scrollIntoView();
  }
  const resetFilters = () => setFilters({ q: "", cat: "all", offers: false, isNew: false });

  function refresh() { renderCategories(); renderOffers(); syncUI(); injectProductsLD(); }

  /* ================= بيانات Schema.org للمنتجات (تُولَّد من البيانات) ================= */
  function injectProductsLD() {
    const items = products.filter(p => p.price).slice(0, 30).map((p, i) => ({
      "@type": "ListItem", position: i + 1,
      item: {
        "@type": "Product", name: p.name, description: p.description || p.name, category: p.category,
        image: p.image && !p.image.startsWith("data:") ? new URL(p.image, location.href).href : undefined,
        offers: {
          "@type": "Offer", price: p.price, priceCurrency: CONFIG.currencyCode,
          availability: p.inStock ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
          seller: { "@type": "Pharmacy", name: CONFIG.siteName }
        }
      }
    }));
    let el = $("ld-products");
    if (!items.length) { if (el) el.remove(); return; }
    if (!el) { el = document.createElement("script"); el.type = "application/ld+json"; el.id = "ld-products"; document.head.appendChild(el); }
    el.textContent = JSON.stringify({ "@context": "https://schema.org", "@type": "ItemList", name: "منتجات " + CONFIG.siteName, itemListElement: items });
  }

  /* ================= مسودة هذا الجهاز ================= */
  function showDraftPill() {
    let el = $("draftPill");
    if (draft && !el) {
      el = document.createElement("button");
      el.id = "draftPill"; el.type = "button"; el.className = "draft-pill";
      el.textContent = "تعرض مسودة محفوظة على هذا الجهاز";
      el.addEventListener("click", openAdmin);
      document.body.appendChild(el);
    }
    if (!draft && el) el.remove();
  }

  /* ================= لوحة التحكم (تُحمَّل عند الطلب فقط) ================= */
  let adminPromise = null;
  function loadAdmin() {
    if (window.PharmacyAdmin) return Promise.resolve(window.PharmacyAdmin);
    if (adminPromise) return adminPromise;
    adminPromise = new Promise((resolve, reject) => {
      const css = document.createElement("link");
      css.rel = "stylesheet"; css.href = "css/admin.css";
      document.head.appendChild(css);
      const js = document.createElement("script");
      js.src = "js/admin.js";
      js.onload = () => resolve(window.PharmacyAdmin);
      js.onerror = () => { adminPromise = null; reject(new Error("admin load failed")); };
      document.head.appendChild(js);
    });
    return adminPromise;
  }
  async function openAdmin() {
    try { (await loadAdmin()).open(); }
    catch (e) { toast("تعذّر تحميل لوحة التحكم. تأكد من وجود ملف js/admin.js"); }
  }

  /* واجهة عامة تستخدمها لوحة التحكم */
  window.Pharmacy = {
    CONFIG, CATEGORIES, esc, ico, catIcon, toast, normalize, normalizeList, discountPct,
    get products() { return products.map(p => ({ ...p })); },
    get isDraft() { return draft; },
    save: list => Repo.save(list),
    reset: () => Repo.reset()
  };

  /* ================= الأحداث ================= */
  function bindEvents() {
    const nav = $("nav"), menuBtn = $("menuToggle"), hs = $("hsearch"), sBtn = $("searchToggle");
    const closePanels = () => {
      nav.classList.remove("is-open"); menuBtn.setAttribute("aria-expanded", "false");
      hs.classList.remove("is-open"); sBtn.setAttribute("aria-expanded", "false");
      menuBtn.firstElementChild.firstElementChild.setAttribute("href", "#i-menu");
    };
    menuBtn.addEventListener("click", () => {
      const open = !nav.classList.contains("is-open");
      closePanels();
      if (open) { nav.classList.add("is-open"); menuBtn.setAttribute("aria-expanded", "true"); menuBtn.firstElementChild.firstElementChild.setAttribute("href", "#i-x"); }
    });
    sBtn.addEventListener("click", () => {
      const open = !hs.classList.contains("is-open");
      closePanels();
      if (open) { hs.classList.add("is-open"); sBtn.setAttribute("aria-expanded", "true"); $("hq").focus(); }
    });
    nav.addEventListener("click", e => { if (e.target.closest("a")) closePanels(); });
    document.addEventListener("click", e => { if (!e.target.closest(".site-header")) closePanels(); });
    document.addEventListener("keydown", e => { if (e.key === "Escape") closePanels(); });

    // البحث (الهيدر وشريط المنتجات حقلان متزامنان)
    const onSearch = e => {
      setFilters({ q: e.target.value });
      if (e.target.id === "hq") {
        const r = $("products").getBoundingClientRect();
        if (r.top > innerHeight * .6 || r.bottom < 0) $("products").scrollIntoView();
      }
    };
    $("q").addEventListener("input", onSearch);
    $("hq").addEventListener("input", onSearch);
    $("hq").addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); $("hq").blur(); closePanels(); $("products").scrollIntoView(); } });
    $("qClear").addEventListener("click", () => { setFilters({ q: "" }); $("q").focus(); });

    // الفلاتر
    $("chips").addEventListener("click", e => { const b = e.target.closest("[data-chip]"); if (b) setFilters({ cat: b.dataset.chip }); });
    $("fOffers").addEventListener("click", () => setFilters({ offers: !state.offers }));
    $("fNew").addEventListener("click", () => setFilters({ isNew: !state.isNew }));
    $("reset").addEventListener("click", resetFilters);
    $("moreBtn").addEventListener("click", () => { state.shown += CONFIG.pageSize; renderGrid(); });
    $("allOffers").addEventListener("click", () => setFilters({ q: "", cat: "all", isNew: false, offers: true }, { scroll: true }));

    // أقسام وروابط تفتح قسمًا / العروض
    document.addEventListener("click", e => {
      const c = e.target.closest("[data-go-cat]");
      if (c) { e.preventDefault(); setFilters({ q: "", offers: false, isNew: false, cat: c.dataset.goCat }, { scroll: true }); return; }
      if (e.target.closest("[data-go-offers]")) { e.preventDefault(); setFilters({ q: "", cat: "all", isNew: false, offers: true }, { scroll: true }); return; }
      if (e.target.closest("[data-reset]")) { resetFilters(); return; }
      if (e.target.closest("[data-order]")) toast("جارٍ فتح واتساب برسالة جاهزة");
    });

    // صورة منتج مفقودة → أيقونة القسم بدل صورة مكسورة
    const onImgError = e => {
      const img = e.target;
      if (!img.classList || !img.classList.contains("card__img")) return;
      img.outerHTML = `<span class="card__ph">${ico(img.dataset.icon || "pill", 30)}</span>`;
    };
    $("grid").addEventListener("error", onImgError, true);
    $("offersGrid").addEventListener("error", onImgError, true);

    $("admLink").addEventListener("click", e => { e.preventDefault(); openAdmin(); });
    addEventListener("hashchange", () => { if (location.hash === "#admin") openAdmin(); });
  }

  /* ================= التهيئة ================= */
  function fillStatic() {
    $$("[data-wa]").forEach(a => { a.href = WhatsApp.link(a.dataset.waText || WhatsApp.general); });
    $$("[data-text]").forEach(el => { el.textContent = CONFIG[el.dataset.text] || ""; });
    $$("[data-call]").forEach(a => { a.href = "tel:" + CONFIG.phone; });
    $$("[data-ig]").forEach(a => { a.href = "https://instagram.com/" + CONFIG.instagram; });
    $$("[data-ig-text]").forEach(el => { el.textContent = "@" + CONFIG.instagram; });
    $$("[data-map]").forEach(a => { a.href = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(CONFIG.address); });
    $("yr").textContent = new Date().getFullYear();
  }

  async function init() {
    fillStatic();
    renderStaticLists();
    bindEvents();
    products = await Repo.load();
    refresh();
    showDraftPill();
    if (location.hash === "#admin") openAdmin();
  }
  init();
})();
